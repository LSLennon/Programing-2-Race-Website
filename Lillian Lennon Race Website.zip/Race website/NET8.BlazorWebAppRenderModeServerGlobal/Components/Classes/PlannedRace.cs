﻿namespace Race.Components.Classes
{
    public class PlannedRace
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public List<RaceAnimal> Horses { get; set; }

        public PlannedRace()
        {
            Horses = new List<RaceAnimal>();
        }
    }

}
