﻿namespace Race.Components.Classes
{
    public class RaceManager : RacePerson
    {
        public RaceManager() : base() { }

        public RaceManager(string fullName, string username, string password)
            : base(fullName, username, password) { }
    }


}
