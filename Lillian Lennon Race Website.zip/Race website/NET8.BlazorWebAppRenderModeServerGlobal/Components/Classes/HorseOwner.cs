﻿namespace Race.Components.Classes
{
    public class HorseOwner : RacePerson
    {
        public List<int> HorseIds { get; set; }
        public HorseOwner() : base()
        {
            HorseIds = new List<int>();
        }

        public HorseOwner(string fullName, string username, string password)
            : base(fullName, username, password)
        {
            HorseIds = new List<int>();
        }
    }


}
