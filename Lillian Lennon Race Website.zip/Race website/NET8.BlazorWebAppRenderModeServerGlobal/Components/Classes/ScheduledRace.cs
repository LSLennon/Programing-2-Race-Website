﻿namespace Race.Components.Classes
{
    public class ScheduledRace
    {
        public int Id { get; set; }
        public TimeOnly EventStart { get; set; }
    }
}
