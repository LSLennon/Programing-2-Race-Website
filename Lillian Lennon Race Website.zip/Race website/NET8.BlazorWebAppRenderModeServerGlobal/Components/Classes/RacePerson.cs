﻿namespace Race.Components.Classes
{
    public abstract class RacePerson : IRacePerson
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public RacePerson(string fullName, string username, string password)
        {
            FullName = fullName;
            Username = username;
            Password = password;
        }

        public RacePerson()
    {
    }
    }

}
