﻿namespace Race.Components.Classes
{
    public interface IRacePerson
    {
        int Id { get; set; }          
        string FullName { get; set; }  
        string Username { get; set; }  
        string Password { get; set; } 
    }

}
