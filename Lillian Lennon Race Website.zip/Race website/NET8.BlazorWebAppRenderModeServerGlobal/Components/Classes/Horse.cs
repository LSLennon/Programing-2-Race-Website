﻿namespace Race.Components.Classes
{
    public class Horse
    {
        public int Id { get; set; }
        public string HorseName { get; set; }
        public string RiderName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string NationOfOrigin { get; set; }
        public string Owner { get; set; }
    }
}
