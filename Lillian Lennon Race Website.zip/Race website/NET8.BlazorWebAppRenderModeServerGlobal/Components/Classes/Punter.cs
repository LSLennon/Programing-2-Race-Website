﻿namespace Race.Components.Classes
{
    public class Punter : RacePerson
    {
        public int AccountBalance { get; set; }
        public Punter() : base()
        {
            AccountBalance = 100;
        }

        public Punter(string fullName, string username, string password)
            : base(fullName, username, password)
        {
            AccountBalance = 100; 
        }
    }


}
