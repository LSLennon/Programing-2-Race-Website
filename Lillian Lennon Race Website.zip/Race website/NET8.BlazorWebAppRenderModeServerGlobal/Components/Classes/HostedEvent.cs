﻿namespace Race.Components.Classes
{
    public class HostedEvent
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public string Location { get; set; }
        public DateOnly Date { get; set; }
        public List<ScheduledRace> ChosenRace { get; set; }

        public HostedEvent()
        {
            ChosenRace = new List<ScheduledRace>();
        }
    }

}
