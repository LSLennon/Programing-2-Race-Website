﻿namespace Race.Components.Classes
{
    public class RaceAnimal
    {
        public int Id { get; set; }
        public double BettingOdds { get; set; }
        public bool Auenticated { get; set; }

        public RaceAnimal() : base()
        {
            Auenticated = false;
        }
    }
}
