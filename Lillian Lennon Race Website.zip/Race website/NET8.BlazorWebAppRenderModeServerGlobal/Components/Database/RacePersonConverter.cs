﻿using System.Text.Json;
using System.Text.Json.Serialization;
using Race.Components.Classes;

public class RacePersonConverter : JsonConverter<RacePerson>
{
    public override RacePerson Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        using (JsonDocument doc = JsonDocument.ParseValue(ref reader))
        {
            var root = doc.RootElement;

            // Type discriminator (ensure 'Type' property is present)
            if (!root.TryGetProperty("Type", out JsonElement typeProperty))
            {
                throw new JsonException("Missing 'Type' discriminator in the JSON.");
            }

            string personType = typeProperty.GetString();

            if (!root.TryGetProperty("details", out JsonElement detailsPrp))
            {
                throw new JsonException("Missing 'Type' discriminator in the JSON.");
            }
            string details = detailsPrp.GetString();

            // Deserialize based on the type value
            switch (personType)
            {
                case "Punter":
                    return JsonSerializer.Deserialize<Punter>(details, options);
                case "RaceManager":
                    return JsonSerializer.Deserialize<RaceManager>(details, options);
                case "HorseOwner":
                    return JsonSerializer.Deserialize<HorseOwner>(details, options);
                default:
                    throw new JsonException($"Unknown RacePerson type: {personType}");
            }
        }
    }

    public override void Write(Utf8JsonWriter writer, RacePerson value, JsonSerializerOptions options)
    {
        writer.WriteStartObject();
        writer.WriteString("Type", value.GetType().Name); // Write the type for discrimination
        writer.WriteString("details", JsonSerializer.Serialize(value));
        writer.WriteEndObject();
    }
}
