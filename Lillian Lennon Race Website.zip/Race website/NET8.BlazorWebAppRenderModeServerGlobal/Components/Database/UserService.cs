﻿using Race.Components.Classes;
using System.Text.Json;

namespace Race.Components.Database
{
    public class UserService
    {
        private const string LoggedInUserFile = "LoggedInUser.json";
        private const string RacePersonsFile = "RacePersons.json"; 

        // Custom deserialization
        private RacePerson DeserializeRacePerson(string jsonString)
        {
            var options = new JsonSerializerOptions
            {
                Converters = { new RacePersonConverter() },
                WriteIndented = true 
            };

            return JsonSerializer.Deserialize<RacePerson>(jsonString, options);
        }

        // Custom serialization
        private string SerializeRacePerson(RacePerson racePerson)
        {
            var options = new JsonSerializerOptions
            {
                Converters = { new RacePersonConverter() },
                WriteIndented = true 
            };

            return JsonSerializer.Serialize(racePerson, options);
        }

        // Login Method
        public bool Login(string username, string password)
        {
            List<RacePerson> racePersons = LoadRacePersonList();

            RacePerson loggedInUser = racePersons
                .FirstOrDefault(rp => rp.Username == username && rp.Password == password);

            if (loggedInUser != null)
            {
                SaveLoggedInUser(loggedInUser);
                return true;
            }

            return false; // Login failed
        }

        // Logout Method
        public void Logout()
        {
            if (File.Exists(LoggedInUserFile))
            {
                File.Delete(LoggedInUserFile); 
            }
        }

        // Add a new RacePerson
        public void Register(RacePerson newUser)
        {
            AddRacePerson(newUser); 
        }

        // Get the currently logged-in
        public RacePerson GetLoggedInUser()
        {
            if (!File.Exists(LoggedInUserFile))
            {
                return null; 
            }

            string jsonString = File.ReadAllText(LoggedInUserFile);
            return DeserializeRacePerson(jsonString); 
        }

        // Save logged-in user to json
        private void SaveLoggedInUser(RacePerson user)
        {
            string jsonString = SerializeRacePerson(user); 
            File.WriteAllText(LoggedInUserFile, jsonString);
        }

        // Load all RacePerson 
        public List<RacePerson> LoadRacePersonList()
        {
            if (!File.Exists("RacePersons.json"))
            {
                return new List<RacePerson>(); 
            }

            string jsonString = File.ReadAllText("RacePersons.json");
            var options = new JsonSerializerOptions
            {
                Converters = { new RacePersonConverter() },
                WriteIndented = true 
            };
           List<RacePerson> racePersons = JsonSerializer.Deserialize<List<RacePerson>>(jsonString, options);
            return racePersons;
        }

        // Add a new RacePerson 
        public void AddRacePerson(RacePerson newRacePerson)
        {
            List<RacePerson> racePersons = LoadRacePersonList(); 

            int nextId = racePersons.Any() ? racePersons.Max(rp => rp.Id) + 1 : 1;

            newRacePerson.Id = nextId;

            racePersons.Add(newRacePerson);

            SaveRacePersonList(racePersons);
        }

        // Save all RacePerson to file
        private void SaveRacePersonList(List<RacePerson> racePersons)
        {
            var options = new JsonSerializerOptions
            {
                Converters = { new RacePersonConverter() },
                WriteIndented = true 
            };

            string jsonString = JsonSerializer.Serialize(racePersons, options);
            File.WriteAllText("RacePersons.json", jsonString);
        }
    }
}
