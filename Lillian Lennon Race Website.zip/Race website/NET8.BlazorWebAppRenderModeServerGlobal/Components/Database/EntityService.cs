﻿using System.Text.Json;
using System.Reflection;

namespace Race.Components.Database
{
    public class EntityService<T> where T : class
    {
        private readonly string filePath;

        public EntityService(string fileName)
        {
            this.filePath = fileName;
        }

        public void AddEntity(T newEntity)
        {
            List<T> entities = LoadEntitiesFromFile();

            int nextId = entities.Any() ? entities.Max(e => (int)GetPropertyValue(e, "Id")) + 1 : 1;

            SetPropertyValue(newEntity, "Id", nextId);

            entities.Add(newEntity);
            SaveEntitiesToFile(entities);
        }

        // Load entities from file
        public List<T> LoadEntitiesFromFile()
        {
            if (!File.Exists(filePath))
            {
                return new List<T>(); 
            }

            string jsonString = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<List<T>>(jsonString);
        }

        // Save entities to file
        public void SaveEntitiesToFile(List<T> entities)
        {
            string jsonString = JsonSerializer.Serialize(entities);
            File.WriteAllText(filePath, jsonString);
        }

        // Delete entity by Id
        public void DeleteEntity(int id)
        {
            List<T> entities = LoadEntitiesFromFile();
            var entityToDelete = entities.FirstOrDefault(e => (int)GetPropertyValue(e, "Id") == id);

            if (entityToDelete != null)
            {
                entities.Remove(entityToDelete);
                SaveEntitiesToFile(entities);
            }
        }

        // get a property value by 
        private object GetPropertyValue(T entity, string propertyName)
        {
            PropertyInfo property = typeof(T).GetProperty(propertyName);
            return property != null ? property.GetValue(entity) : null;
        }

        // set a property value by name 
        private void SetPropertyValue(T entity, string propertyName, object value)
        {
            PropertyInfo property = typeof(T).GetProperty(propertyName);
            if (property != null && property.CanWrite)
            {
                property.SetValue(entity, value);
            }
        }
    }
}
